<?php
//pitem el contingut de l'array
foreach ($_SERVER as $clau => $valor) {
    echo "El valor de [$clau] és [$valor] <br>";
}
