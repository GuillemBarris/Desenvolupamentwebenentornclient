<?php
$i = 12;
$tipus_de_i = gettype($i);
echo "La variable \$i 
      conté el valor $i 
	  i és del tipus $tipus_de_i<br>";
$i = 12.01;
$tipus_de_i = gettype($i);
echo "La variable \$j 
      conté el valor $i 
	  i és del tipus $tipus_de_i<br>";
$i = true;
$tipus_de_i = gettype($i);
echo "La variable \$k 
      conté el valor $i 
	  i és del tipus $tipus_de_i<br>";
$i = "12";
$tipus_de_i = gettype($i);
echo "La variable \$l 
      conté el valor $i 
	  i és del tipus $tipus_de_i<br>";
